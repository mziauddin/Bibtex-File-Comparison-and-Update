Requirements
============

To run this widget application , you need to :

Install MongoDb . Use the below link to install and start the mongoDb server on your machine
	- https://docs.mongodb.org/manual/installation/
