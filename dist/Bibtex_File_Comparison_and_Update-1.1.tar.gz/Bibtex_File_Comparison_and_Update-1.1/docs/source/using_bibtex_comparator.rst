=======================
Using bibtex comparator
=======================

* Two ways of selecting the files:

	* Hard disk

	.. image:: images/select_disk.png	

	Then you can go ahead and select the local file and the master file from the disk

	.. image:: images/select_disk_files.png	


	* Git Repo

	.. image:: images/select_git.png

	You can select the local file and master file from the list of bibtex files in each repo provided

	.. image:: images/select_git_files.png

* Choose the updates you want to make to the local file and press done:

.. image:: images/select_file_update.png