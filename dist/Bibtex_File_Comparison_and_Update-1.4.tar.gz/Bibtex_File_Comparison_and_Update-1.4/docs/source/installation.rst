============
Installation
============

* Download the tar file Bibtex_File_Comparison_and_Update 1.3 from https://pypi.python.org/pypi?:action=display&name=Bibtex_File_Comparison_and_Update&version=1.3
* Untar the file and store it locally
* Run ``sudo python setup.py install`` for a local installation of the package
* Run ``python setup.py test`` to run the test-suite
* Run script to begin the application 