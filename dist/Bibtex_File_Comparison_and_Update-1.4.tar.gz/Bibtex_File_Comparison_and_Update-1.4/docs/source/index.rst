.. bibtex_project documentation master file, created by
   sphinx-quickstart on Sun Dec 13 14:12:11 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to bibtex_project's documentation!
==========================================

	

Contents:

.. toctree::
	:maxdepth: 2
	
	requirements
	installation
	bibtex_comparator
	view
	model
	controller


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

