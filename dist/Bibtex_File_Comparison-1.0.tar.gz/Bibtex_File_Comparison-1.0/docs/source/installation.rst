============
Installation
============

Simply run:

    * pip install bibtex_comparator
	* Run ``sudo python setup.py install`` for a local installation of the package
	* Run ``python setup.py test`` to run the test-suite
	* Run script to begin the application 